package com.example.demo;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Create root pane
        Pane root = new Pane();
        root.setId("img1");
        root.setPrefSize(948, 541);
        root.getStylesheets().add("Home.css");

        // Create AnchorPane
        AnchorPane anchorPane = new AnchorPane();
        anchorPane.setId("an2");
        anchorPane.setLayoutX(101);
        anchorPane.setLayoutY(68);
        anchorPane.setPrefSize(727, 422);
        anchorPane.getStylesheets().add("Home.css");

        // Create Label
        Label label = new Label("ACCOUNT");
        label.setId("lab1");
        label.setLayoutX(523);
        label.setLayoutY(140);
        label.setPrefSize(91, 18);
        label.setFont(Font.font("Times New Roman Bold", 18));

        // Create Button
        Button button = new Button("CONFIRM");
        button.setId("btn1");
        button.setDefaultButton(true);
        button.setLayoutX(495);
        button.setLayoutY(323);
        button.setPrefSize(146, 29);
        button.setTextFill(javafx.scene.paint.Color.WHITE);
        button.setFont(Font.font("Times New Roman Bold", 14));

        // Create ImageView for account image
        ImageView accountImageView = new ImageView("account.png");
        accountImageView.setId("V");
        accountImageView.setFitHeight(55);
        accountImageView.setFitWidth(57);
        accountImageView.setLayoutX(540);
        accountImageView.setLayoutY(61);
        accountImageView.setPreserveRatio(true);
        accountImageView.setSmooth(false);

        // Create TextField for card number
        TextField textField = new TextField();
        textField.setId("text");
        textField.setAlignment(javafx.geometry.Pos.CENTER);
        textField.setLayoutX(444);
        textField.setLayoutY(195);
        textField.setPrefSize(250, 30);
        textField.setPromptText("    Card Number");
        textField.setFont(Font.font("Times New Roman Bold", 15));

        // Create ImageView for admin image
        ImageView adminImageView = new ImageView(new Image(("Admin.png")));
        adminImageView.setFitHeight(30);
        adminImageView.setFitWidth(25);
        adminImageView.setLayoutX(452);
        adminImageView.setLayoutY(197);
        adminImageView.setPickOnBounds(true);
        adminImageView.setPreserveRatio(true);

        // Create Label for error message
        Label errorMsgLabel = new Label();
        errorMsgLabel.setId("errormsg");
        errorMsgLabel.setDisable(true);
        errorMsgLabel.setLayoutX(140);
        errorMsgLabel.setLayoutY(235);
        errorMsgLabel.setPrefSize(17, 18);
        errorMsgLabel.setFont(Font.font("Calibri", 14));

        // Create AnchorPane for logo
        AnchorPane logoAnchorPane = new AnchorPane();
        logoAnchorPane.setId("an3");
        logoAnchorPane.setLayoutY(-1);
        logoAnchorPane.setPrefSize(411, 429);
        logoAnchorPane.getStylesheets().add("Home.css");

        // Create ImageView for logo image
        ImageView logoImageView = new ImageView(new Image(("Logo.png")));
        logoImageView.setFitHeight(87);
        logoImageView.setFitWidth(311);
        logoImageView.setLayoutX(61);
        logoImageView.setLayoutY(165);
        logoImageView.setPickOnBounds(true);
        logoImageView.setPreserveRatio(true);

        // Create TextField for pin number
        TextField passTextField = new TextField();
        passTextField.setId("pass");
        passTextField.setAlignment(javafx.geometry.Pos.CENTER);
        passTextField.setDisable(true);
        passTextField.setLayoutX(445);
        passTextField.setLayoutY(256);
        passTextField.setPrefSize(250, 30);
        passTextField.setPromptText(" Pin Number");
        passTextField.setFont(Font.font("Times New Roman Bold", 15));

        // Create ImageView for padlock image
        ImageView padlockImageView = new ImageView(new Image(("padlock.png")));
        padlockImageView.setDisable(true);
        padlockImageView.setFitHeight(30);
        padlockImageView.setFitWidth(25);
        padlockImageView.setLayoutX(451);
        padlockImageView.setLayoutY(259);
        padlockImageView.setPickOnBounds(true);
        padlockImageView.setPreserveRatio(true);

        // Add children to anchorPane
        anchorPane.getChildren().addAll(label, button, accountImageView, textField, adminImageView, errorMsgLabel, logoAnchorPane, passTextField, padlockImageView);
        logoAnchorPane.getChildren().add(logoImageView);

        // Add anchorPane to root
        root.getChildren().add(anchorPane);

        // Create scene and set stage
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.setTitle("FXML to JavaFX");
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
